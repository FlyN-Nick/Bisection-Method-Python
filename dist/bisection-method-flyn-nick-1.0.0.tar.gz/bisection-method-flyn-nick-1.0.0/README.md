# Bisection-Method-Python
A quick implementation of the Bisection Method in Python.
