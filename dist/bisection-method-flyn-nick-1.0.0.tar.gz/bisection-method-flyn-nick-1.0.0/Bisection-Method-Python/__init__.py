from bisection import bisection

exampleFuncs = {
  'linFuncString': '2*x-19',
  'polyFunc': 'x**2+x-5',
  'trigFuncOne': 'math.sin(1/x)',
  'trigFuncTwo': 'math.sin(x)/x' 
}
