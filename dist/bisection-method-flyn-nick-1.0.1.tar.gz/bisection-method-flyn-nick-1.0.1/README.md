# Bisection-Method-Python
A quick implementation of the Bisection Method in Python.
To install run the below command:
```
pip install bisection-method-flyn-nick
```
